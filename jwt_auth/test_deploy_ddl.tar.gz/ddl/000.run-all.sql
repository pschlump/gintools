
-- Only need to run onece after creatingon of acocunt
\i 000.setup.sql

\i 001.tables.sql

\i 002.data.sql

