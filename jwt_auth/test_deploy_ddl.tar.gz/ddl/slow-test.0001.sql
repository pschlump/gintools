select q_auth_v1_login ( 'bob@client.com','b','0da4b0d2-4705-439d-4634-85a588717a3b','my long secret password','user info password' );
