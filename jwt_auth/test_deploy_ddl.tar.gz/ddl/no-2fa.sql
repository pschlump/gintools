
update q_qr_config 
	set value = 'no'
		, b_value = false
	where name = 'use.2fa'
;

