DO $$
BEGIN
	BEGIN
		-- ALTER TABLE q_qr_role2 DROP CONSTRAINT IF EXISTS q_qr_role2_u1 ;
		ALTER TABLE q_qr_role2
			ADD CONSTRAINT q_qr_role2_u1
			UNIQUE USING INDEX q_qr_role2_u1
		;
	EXCEPTION
		WHEN duplicate_table THEN	-- postgres raises duplicate_table at surprising times. Ex.: for UNIQUE constraints.
		WHEN duplicate_object THEN
			RAISE NOTICE 'Table constraint q_qr_role2 already exists.';
		WHEN others THEN
			RAISE NOTICE 'Table constraint q_qr_role2 already exists.';
	END;
END $$;

