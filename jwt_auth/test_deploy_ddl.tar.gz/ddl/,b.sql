

-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- 1. q_auth_v1_recover_password_01_setup -> change d.b. - return token. -- (( Indirctly sends email ))
CREATE OR REPLACE FUNCTION q_auth_v1_recover_password_01_setup ( p_email varchar, p_hmac_password varchar, p_userdata_password varchar ) RETURNS text
AS $$
DECLARE
	l_data					text;
	l_first_name			text;
	l_last_name				text;
	l_fail					bool;
	l_recovery_token		uuid;
	v_cnt 					int;
	l_user_id				uuid;
	l_email_hmac			bytea;
	l_n6_flag				text;
	l_recovery_token_n6		text;
BEGIN
	-- Copyright (C) Philip Schlump, 2008-2023.
	-- BSD 3 Clause Licensed.  See LICENSE.bsd
	-- version: m4_ver_version() tag: m4_ver_tag() build_date: m4_ver_date()
	l_fail = false;
	l_data = '{"status":"unknown"}';

	l_recovery_token		= uuid_generate_v4();
	l_recovery_token_n6		= l_recovery_token::text;


	if not l_fail then
		-- (fixed) xyzzy-Slow!! - better to do select count - and verify where before update.
		l_email_hmac = q_auth_v1_hmac_encode ( p_email, p_hmac_password );
		with user_row as (
			select
				  user_id
				, pgp_sym_decrypt(first_name_enc,p_userdata_password)::text as first_name
				, pgp_sym_decrypt(last_name_enc,p_userdata_password)::text as last_name
				, email_hmac
				, parent_user_id
				, account_type
				, start_date
				, end_date
				, email_validated
				, setup_complete_2fa
				, require_2fa
				, n6_flag
			from q_qr_users as t1
			where t1.email_hmac = l_email_hmac
		)
		select
			  user_id
		    , first_name
		    , last_name
			, n6_flag
		into
			  l_user_id
			, l_first_name
			, l_last_name
			, l_n6_flag
		from user_row
		where parent_user_id is null
		  and account_type = 'login'
		  and ( start_date < current_timestamp or start_date is null )
		  and ( end_date > current_timestamp or end_date is null )
		  and email_validated = 'y'
		  and ( setup_complete_2fa = 'y' or require_2fa = 'n' )
		for update
		;
		if not found then

			-- Select to get l_user_id for email.  If it is not found above then this may not be a fully setup user.
			-- The l_user_id is used below in a delete to prevent marking of devices as having been seen.
			select user_id
				into l_user_id
				from q_qr_users as t1
				where t1.email_hmac = l_email_hmac
				;

			if not found then
				l_fail = true;
				l_data = '{"status":"error","msg":"Invalid Username / Invalid account.","code":"m4_count()","location":"m4___file__ m4___line__"}';
			else 
				l_fail = true;
				l_data = '{"status":"error","msg":"Account not valided or email not validated.","code":"m4_count()","location":"m4___file__ m4___line__"}';
			end if;

		end if;
	end if;

	-- Delete all the id.json rows for this user - every marked device will need to 2fa after this request.
	delete from q_qr_device_track where user_id = l_user_id;

	if not l_fail then
		update q_qr_users as t1
			set
				  password_reset_token = l_recovery_token
				, password_reset_time = current_timestamp + interval '1 hours'
			where t1.user_id = l_user_id
			;
		-- check # of rows.
		GET DIAGNOSTICS v_cnt = ROW_COUNT;
		if v_cnt != 1 then
			l_fail = true;
			l_data = '{"status":"error","msg":"Invalid Username or Account not valid or email not validated","code":"m4_count()","location":"m4___file__ m4___line__"}';
			insert into q_qr_auth_log ( user_id, activity, code, location ) values ( l_user_id, 'Invalid Username or Account not valid or email not validated', 'm4_counter()', 'File:m4___file__ Line No:m4___line__');
		end if;

		if l_n6_flag = 'n6' or l_n6_flag = 'n8' then
			l_recovery_token_n6 = q_auth_v1_n6_email_validate ( l_recovery_token, l_n6_flag );
		else 
			l_recovery_token_n6 = l_recovery_token;
		end if;

	end if;

	if not l_fail then
		l_data = '{"status":"success"'
			||', "recovery_token":'   	||coalesce(to_json(l_recovery_token)::text,'""')
			||', "recovery_token_n6":'	||coalesce(to_json(l_recovery_token_n6)::text,'""')
			||', "first_name":'   		||coalesce(to_json(l_first_name)::text,'""')
			||', "last_name":'   		||coalesce(to_json(l_last_name)::text,'""')
			||', "n6_flag":'   			||coalesce(to_json(l_n6_flag)::text,'""')
			||'}';
	end if;

	RETURN l_data;
END;
$$ LANGUAGE plpgsql;



