\c autojob
\i 001.tables.sql
\q
