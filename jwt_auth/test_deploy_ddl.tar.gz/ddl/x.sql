
select 'before' ;

\q

select 'bad' ;

