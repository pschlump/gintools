SELECT * FROM pg_stat_ssl;
