CREATE OR REPLACE FUNCTION q_auth_v1_login ( p_email varchar, p_pw varchar, p_am_i_known varchar, p_hmac_password varchar, p_userdata_password varchar, p_fingerprint varchar, p_sc_id varchar, p_hash_of_headers varchar, p_xsrf_id varchar ) RETURNS text
AS $$
DECLARE
	l_2fa_id				uuid;
	l_data					text;
	l_fail					bool;
  	l_user_id 				uuid;
	l_junk					text;
	l_email_validated		varchar(1);
	l_setup_complete_2fa 	varchar(1);
	l_start_date			timestamp;
	l_end_date				timestamp;
	l_require_2fa 			varchar(1);
	l_secret_2fa 			varchar(20);
	l_account_type			varchar(20);
	l_privileges			text;
	l_user_config			text;
	l_first_name			text;
	l_last_name				text;
	l_tmp					text;
	l_auth_token			uuid;
	l_tmp_token				uuid;	-- when 2fa is on this is returnd as not null (UUID)
	l_debug_on 				bool;
	l_failed_login_timeout 	timestamp;
	l_login_failures 		int;
	l_one_time_password_id 	uuid;
	v_cnt 					int;
	l_validation_method		varchar(10);
	l_manifest_id			uuid;
	l_email_hmac            bytea;
	l_otp_hmac              text;
	l_is_new_device_login	varchar(1);
	l_client_id				uuid;
	l_acct_state			text;
	l_role_name				text;
	l_is_new_device_msg		text;
	l_device_track_id		uuid;
BEGIN
	l_debug_on = q_get_config_bool ( 'debug' );

	-- Copyright (C) Philip Schlump, 2008-2023.
	-- BSD 3 Clause Licensed.  See LICENSE.bsd
	-- version: df6e457c9e341a491c4ebedfefabd61ad53549f3 tag: v1.0.42 build_date: Tue Nov 14 08:46:44 MST 2023
	l_fail = false;
	l_data = '{"status":"unknown"}';
	l_is_new_device_login = 'n';
	l_is_new_device_msg = '--don''t-know--';

	if l_debug_on then
		insert into t_output ( msg ) values ( 'function ->q_quth_v1_login<- 001.tables.m4.sql 5631' );
		insert into t_output ( msg ) values ( '  p_email ->'||coalesce(to_json(p_email)::text,'---null---')||'<-');
		insert into t_output ( msg ) values ( '  p_pw ->'||coalesce(to_json(p_pw)::text,'---null---')||'<-');
		insert into t_output ( msg ) values ( '  p_am_i_known ->'||coalesce(to_json(p_am_i_known)::text,'---null---')||'<-');
		insert into t_output ( msg ) values ( '  p_hmac_password ->'||coalesce(to_json(p_hmac_password)::text,'---null---')||'<-');
		insert into t_output ( msg ) values ( '  p_userdata_password ->'||coalesce(to_json(p_userdata_password)::text,'---null---')||'<-');
		insert into t_output ( msg ) values ( '  p_fingerprint ->'||coalesce(to_json(p_fingerprint)::text,'---null---')||'<-');
		insert into t_output ( msg ) values ( '  p_sc_id ->'||coalesce(to_json(p_sc_id)::text,'---null---')||'<-');
		insert into t_output ( msg ) values ( '  p_hash_of_headers ->'||coalesce(to_json(p_hash_of_headers)::text,'---null---')||'<-');
		insert into t_output ( msg ) values ( '  p_xsrf_id ->'||coalesce(to_json(p_xsrf_id)::text,'---null---')||'<-');
		insert into t_output ( msg ) values ( '  ' );
	end if;

	l_junk = q_auth_v1_cleanup_old_data();

	-- --------------------------------------------------------------------------------------------------------------------------------------------------------
	-- New Device
	-- --------------------------------------------------------------------------------------------------------------------------------------------------------
	-- If not found, ( p_am_i_known???, p_fingerprint , p_sc_id, p_hash_of_headers )
	--		l_is_new_device_msg = 'based on: (a,b,c) not found this is a new device.
	-- IF successful login THEN : Create new row in q_qr_device_track with entries, create dependent row with l_xsrf_id into q_qr_valid_xsrf_id. 	Set loign count to 1.
	-- IF not new device THEN: if xsrf_id not in q_qr_valid_xsrf_id, for this user, then if successful login, create new row for l_xsrf_id.
	-- IF not new device THEN: if succesful login then: update login count for this device.
	-- --------------------------------------------------------------------------------------------------------------------------------------------------------
	--
	-- 
	--
	-- xyzzy8 - fingerprint
	select id
		into l_device_track_id		
		from q_qr_device_track as t1
		where t1.fingerprint_data = p_fingerprint
		  and t1.sc_id = p_sc_id
		  and t1.header_hash = p_hash_of_headers
		limit 1
		;

	if not found then
		l_is_new_device_login = 'y';
		l_is_new_device_msg = 'new device, test 1';
	else
		l_is_new_device_login = 'n';
		l_is_new_device_msg = 'Existing device fingerprint/sc_id/header_hash match';
	end if;


	-- validation_method		varchar(10) default 'un/pw' not null check ( validation_method in ( 'un/pw', 'sip', 'srp6a', 'hw-key' ) ),
	if not l_fail then
		l_email_hmac = q_auth_v1_hmac_encode ( p_email, p_hmac_password );
		-- see:(this one has been fixed) xyzzy-Slow!! - better to do select count - and verify where before update.
		with email_user as (
			select
				  user_id
				, email_validated
				, setup_complete_2fa
				, start_date
				, end_date
				, require_2fa
				, secret_2fa
				, account_type
				, pgp_sym_decrypt(first_name_enc,p_userdata_password)::text as x_first_name
				, pgp_sym_decrypt(last_name_enc,p_userdata_password)::text as x_last_name
				, failed_login_timeout
				, login_failures
				, validation_method
				, password_hash
				, parent_user_id
				, client_id
				, acct_state				
				, role_name				
			from q_qr_users
			where email_hmac = l_email_hmac
		)
		select
				  user_id
				, email_validated
				, setup_complete_2fa
				, start_date
				, end_date
				, require_2fa
				, secret_2fa
				, account_type
				, x_first_name
				, x_last_name
				, failed_login_timeout
				, login_failures
				, validation_method
				, client_id
				, acct_state
				, role_name				
			into
				  l_user_id
				, l_email_validated
				, l_setup_complete_2fa
				, l_start_date
				, l_end_date
				, l_require_2fa
				, l_secret_2fa
				, l_account_type
				, l_first_name
				, l_last_name
				, l_failed_login_timeout
				, l_login_failures
				, l_validation_method
				, l_client_id
				, l_acct_state
				, l_role_name				
			from email_user
		    where
				(
					    account_type = 'login'
					and password_hash = crypt(p_pw, password_hash)
					and parent_user_id is null
				)  or (
					    account_type = 'un/pw'
					and password_hash = crypt(p_pw, password_hash)
					and parent_user_id is not null
				)  or (
					    account_type = 'token'
					and parent_user_id is not null
				)
		;

		if not found then -- BBB
			select
				  user_id
				, email_validated
				, setup_complete_2fa
				, start_date
				, end_date
				, require_2fa
				, secret_2fa
				, account_type
				, pgp_sym_decrypt(first_name_enc,p_userdata_password)::text as x_first_name
				, pgp_sym_decrypt(last_name_enc,p_userdata_password)::text as x_last_name
				, failed_login_timeout
				, login_failures
				, validation_method
				, client_id
				, acct_state
				, role_name				
			into l_user_id
				, l_email_validated
				, l_setup_complete_2fa
				, l_start_date
				, l_end_date
				, l_require_2fa
				, l_secret_2fa
				, l_account_type
				, l_first_name
				, l_last_name
				, l_failed_login_timeout
				, l_login_failures
				, l_validation_method
				, l_client_id
				, l_acct_state
				, l_role_name				
			from q_qr_users
			where email_hmac = l_email_hmac
			;
			if not found then
				l_fail = true;
				l_data = '{"status":"error","msg":"Invalid Username or Password","code":"2053","location":"001.tables.m4.sql 5807"}'; -- return no such account or password
				insert into q_qr_auth_log ( user_id, activity, code, location ) values ( l_user_id, 'Invalid Username or Password', '2053', 'File:001.tables.m4.sql Line No:5808');
			end if;

			if not l_fail then -- AAA

				-- ------------------------------------------------------------------------------------------
				-- Place to check if password is an OTP password and handle that
				-- ------------------------------------------------------------------------------------------

				-- should be an _hmac for otp - not a crypt - need to access this quickly

				l_otp_hmac = q_auth_v1_hmac_encode ( p_pw, p_hmac_password );

				select
						t2.one_time_password_id
					into
						l_one_time_password_id
					from q_qr_one_time_password as t2
					where t2.user_id = l_user_id
					  and t2.otp_hmac = l_otp_hmac
				;

				if found then
					if l_debug_on then
						insert into t_output ( msg ) values ( '  ((( Login is a successful OTP password login )))' );
					end if;
					l_require_2fa = 'n';		-- Turn off 1fa - they have the paper OTP as 2nd factor.
					delete from q_qr_one_time_password where one_time_password_id = l_one_time_password_id;
					insert into q_qr_auth_log ( user_id, activity, code, location ) values ( l_user_id, 'Used Ont Time Password', '2053', 'File:001.tables.m4.sql Line No:5836');
				else
					l_fail = true;
					l_data = '{"status":"error","msg":"Invalid Username or Password","code":"2054","location":"001.tables.m4.sql 5839"}'; -- return no such account or password
					insert into q_qr_auth_log ( user_id, activity, code, location ) values ( l_user_id, 'Invalid Username or Password', '2054', 'File:001.tables.m4.sql Line No:5840');
				end if;

			end if; -- AAA

		end if; -- BBB

	end if;

	if l_debug_on then
		insert into t_output ( msg ) values ( '   Additional Fields ' );
		insert into t_output ( msg ) values ( '  ->'||coalesce(to_json(p_userdata_password)::text,'---null---')||'<-');
		insert into t_output ( msg ) values ( '  l_first_name           = ->'||coalesce(to_json(l_first_name)::text,'---null---')||'<-');
		insert into t_output ( msg ) values ( '  l_last_name            = ->'||coalesce(to_json(l_last_name)::text,'---null---')||'<-');
		insert into t_output ( msg ) values ( '  l_validation_method    = ->'||coalesce(to_json(l_validation_method)::text,'---null---')||'<-');
		insert into t_output ( msg ) values ( '  l_start_date           = ->'||coalesce(to_json(l_start_date)::text,'---null---')||'<-');
		insert into t_output ( msg ) values ( '  l_end_date             = ->'||coalesce(to_json(l_end_date)::text,'---null---')||'<-');
		insert into t_output ( msg ) values ( '  l_email_validated      = ->'||coalesce(to_json(l_email_validated)::text,'---null---')||'<-');
		insert into t_output ( msg ) values ( '  l_setup_complete_2fa   = ->'||coalesce(to_json(l_setup_complete_2fa)::text,'---null---')||'<-');
		insert into t_output ( msg ) values ( '  l_client_id            = ->'||coalesce(to_json(l_client_id)::text,'---null---')||'<-');
		insert into t_output ( msg ) values ( '  l_acct_state           = ->'||coalesce(to_json(l_acct_state)::text,'---null---')||'<-');
		insert into t_output ( msg ) values ( '  l_require_2fa          = ->'||coalesce(to_json(l_require_2fa)::text,'---null---')||'<-');
		insert into t_output ( msg ) values ( '  l_otp_hmac             = ->'||coalesce(to_json(l_otp_hmac)::text,'---null---')||'<-');
		insert into t_output ( msg ) values ( '  l_one_time_password_id = ->'||coalesce(to_json(l_one_time_password_id)::text,'---null---')||'<-');
		insert into t_output ( msg ) values ( '  l_role_name            = ->'||coalesce(to_json(l_role_name)::text,'---null---')||'<-');
	end if;

	if l_role_name is null then
		l_role_name = 'role:user';
	end if;
	if l_role_name = '' then
		l_role_name = 'role:user';
	end if;

	if not l_fail then
		if not q_admin_HasPriv ( l_user_id, 'May Login' ) then
			if l_debug_on then
				insert into t_output ( msg ) values ( 'Failed to find priv ''May Login'' ->'||l_user_id||'<-');
			end if;
			l_fail = true;
			l_data = '{"status":"error","msg":"Account lacks ''May Login'' privilege","code":"2055","location":"001.tables.m4.sql 5880"}';
			insert into q_qr_auth_log ( user_id, activity, code, location ) values ( l_user_id, 'Account lacks ''May Login'' privilege', '2055', 'File:001.tables.m4.sql Line No:5881');
		end if;
	end if;

	if not l_fail then
		if l_validation_method != 'un/pw' then
			l_fail = true;
			l_data = '{"status":"error","msg":"Account is not a un/pw authetication method","code":"2056","location":"001.tables.m4.sql 5888"}';
			insert into q_qr_auth_log ( user_id, activity, code, location ) values ( l_user_id, 'Account is not a un/pw autetication method', '2056', 'File:001.tables.m4.sql Line No:5889');
		end if;
	end if;

-- xyzzy99 - must be a chagne to make somwre in this code

	if not l_fail then
		if l_email_validated = 'n' then
			-- Indicates partial registration, email_validated == "n", - code==="0020"
			l_fail = true;
			l_data = '{"status":"error","msg":"Account has not been validated","code":"2057","location":"001.tables.m4.sql 5899"}';
			insert into q_qr_auth_log ( user_id, activity, code, location ) values ( l_user_id, 'Account has not been validated', '2057', 'File:001.tables.m4.sql Line No:5900');
		end if;
	end if;

	if l_require_2fa = 'y' then
		if not l_fail then
			if l_setup_complete_2fa = 'n' then
				-- Indicates partial registration, setup_complete_2fa == "n", - code==="0220"
				l_fail = true;
				l_data = '{"status":"error","msg":"Account has not had 2Fa setup","code":"2058","location":"001.tables.m4.sql 5909"}';
				insert into q_qr_auth_log ( user_id, activity, code, location ) values ( l_user_id, 'Account has not had 2Fa setup', '2058', 'File:001.tables.m4.sql Line No:5910');
			end if;
		end if;
	end if;

	if not l_fail then
		if l_start_date is not null then
			if l_start_date > current_timestamp then
				l_fail = true;
				l_data = '{"status":"error","msg":"Account has a start date that has not been reached","code":"2059","location":"001.tables.m4.sql 5919"}';
			insert into q_qr_auth_log ( user_id, activity, code, location ) values ( l_user_id, 'Account has start date that has not been reached', '2059', 'File:001.tables.m4.sql Line No:5920');
			end if;
		end if;
	end if;

	if not l_fail then
		if l_end_date is not null then
			if l_end_date <= current_timestamp then
				l_fail = true;
				l_data = '{"status":"error","msg":"Account has an end date that has been reached","code":"2060","location":"001.tables.m4.sql 5929"}';
				insert into q_qr_auth_log ( user_id, activity, code, location ) values ( l_user_id, 'Account has end date that has been reached', '2060', 'File:001.tables.m4.sql Line No:5930');
			end if;
		end if;
	end if;

	if not l_fail then
		l_auth_token = NULL;
		-- xyzzy8 - fingerprint -- add 3 params (done)
		if l_require_2fa = 'y' and p_am_i_known is not null then
			if p_am_i_known <> '' then
				-- id.json - check to see if user has been seen before on this device.
				select
						  t1.id
					into
						  l_manifest_id
					from q_qr_device_track as t1
					where t1.id = p_am_i_known::uuid
					  and t1.user_id = l_user_id
				;
				if not found then
					if l_debug_on then
						insert into t_output ( msg ) values ( ' etag not found ' );
					end if;
					l_is_new_device_login = 'y';
				else
					update q_qr_device_track as t1
						set updated = current_timestamp
						  , n_login = n_login + 1
						where t1.id = l_manifest_id
					;
					l_require_2fa = 'n';
					if l_debug_on then
						insert into t_output ( msg ) values ( ' skipping 2fa token - device is known ' );
					end if;
				end if;
			end if;
		end if;
		if l_require_2fa = 'n' then
			-- insert / create auth_token
			l_auth_token = uuid_generate_v4();
			BEGIN
				insert into q_qr_auth_tokens ( token, user_id ) values ( l_auth_token, l_user_id );
			EXCEPTION WHEN unique_violation THEN
				l_fail = true;
				l_data = '{"status":"error","msg":"Unable to create user/auth-token.","code":"2061","location":"001.tables.m4.sql 5974"}';
				insert into q_qr_auth_log ( user_id, activity, code, location ) values ( l_user_id, 'Unable to create user/auth-token.', '2061', 'File:001.tables.m4.sql Line No:5975');
			END;
		end if;
	end if;

	if not l_fail then
		if l_login_failures >= 6 and l_failed_login_timeout >= current_timestamp then
			l_fail = true;
			l_data = '{"status":"error","msg":"Too many failed login attempts - please wait 1 minute.","code":"2062","location":"001.tables.m4.sql 5983"}';
			insert into q_qr_auth_log ( user_id, activity, code, location ) values ( l_user_id, 'Too many failed login attempts - please wait 1 minute.', '2062', 'File:001.tables.m4.sql Line No:5984');
			update q_qr_users
				set failed_login_timeout = current_timestamp + interval '1 minute'
				where user_id = l_user_id
				  and failed_login_timeout is null
				;
		end if;
	end if;

	if not l_fail then
		-- xyzzy9999
		--select json_agg(t1.priv_name)::text
		--	into l_privileges
		--	from q_qr_user_to_priv as t1
		--	where t1.user_id = l_user_id
		--	;

		select json_agg(t0.priv_name)::text
		into l_privileges
		from ( 
			select json_object_keys(t1.allowed::json)::text  as priv_name
				from q_qr_role2 as t1
				where t1.role_name = l_role_name
			) as t0
			;

		-- xyzzyError100 - never true iff.
		if not found then
			if l_debug_on then
				insert into t_output ( msg ) values ( 'Failed to get the privileges for the user' );
			end if;
			l_fail = true;
			l_data = '{"status":"error","msg":"Unable to get privileges for the user.","code":"2063","location":"001.tables.m4.sql 6016"}';
			l_privileges = '[]';
		end if;
	end if;

	if not l_fail then
		l_user_config = '[]';

		-- q8_user_config.sql
		select
				json_agg(
					json_build_object(
						'config_id', config_id,
						'name', name,
						'value', value
					)
				)::text as data
			into l_user_config
			from q_qr_user_config as t1
			where t1.user_id = l_user_id
			;

		if not found then
			l_user_config = '[]';
		end if;
	end if;

	if not l_fail then

		if l_debug_on then
			insert into t_output ( msg ) values ( 'function ->q_quth_v1_login<-..... Continued ...  001.tables.m4.sql 6046' );
			insert into t_output ( msg ) values ( 'calculate l_user_id ->'||coalesce(to_json(l_user_id)::text,'---null---')||'<-');
			insert into t_output ( msg ) values ( 'calculate l_privs ->'||coalesce(l_privileges,'---null---')||'<-');
			insert into t_output ( msg ) values ( 'calculate l_client_id ->'||coalesce(to_json(l_client_id)::text,'---null---')||'<-');
		end if;
		update q_qr_users
			set
				  failed_login_timeout = null
				, login_failures = 0
				, login_success = login_success + 1
				, privileges = l_privileges
		  		, email_verify_token = null
			where user_id = l_user_id
			;
		l_tmp_token = uuid_generate_v4();
		insert into q_qr_tmp_token ( user_id, token ) values ( l_user_id, l_tmp_token );
		if l_debug_on then
			insert into t_output ( msg ) values ( ' l_tmp_token ->'||coalesce(to_json(l_tmp_token)::text,'---null---')||'<-');
		end if;
		if l_require_2fa = 'y' then
			l_auth_token = NULL;
			insert into q_qr_auth_security_log ( user_id, activity, location ) values ( l_user_id, 'Login - Part 1 Success: '||l_tmp_token::text, 'File:001.tables.m4.sql Line No:6067');
		else
			insert into q_qr_auth_security_log ( user_id, activity, location ) values ( l_user_id, 'Successful Login', 'File:001.tables.m4.sql Line No:6069');
			if l_is_new_device_login = 'y' then

				insert into q_qr_device_track (
					  fingerprint_data 
					, sc_id 
					, header_hash 
					, user_id
					, am_i_known
				) values (
					  p_fingerprint
					, p_sc_id
					, p_hash_of_headers
					, l_user_id
					, p_am_i_known
				) returning id into l_device_track_id;

			else 

				update q_qr_device_track 
					set n_login = n_login + 1			
					  , am_i_known = p_am_i_known
					where id = l_device_track_id;

			end if;

			insert into q_qr_valid_xsrf_id (
				  device_track_id
				, user_id			
				, xsrf_id			
			) values (
				  l_device_track_id
				, l_user_id
				, p_xsrf_id::uuid
			);

		end if;
		l_data = '{"status":"success"'
			||', "user_id":'     			||coalesce(to_json(l_user_id)::text,'""')
			||', "auth_token":'  			||coalesce(to_json(l_auth_token)::text,'""')
			||', "tmp_token":'   			||coalesce(to_json(l_tmp_token)::text,'""')
			||', "require_2fa":' 			||coalesce(to_json(l_require_2fa)::text,'""')
			||', "secret_2fa":'  			||coalesce(to_json(l_secret_2fa)::text,'""')
			||', "account_type":'			||coalesce(to_json(l_account_type)::text,'""')
			||', "privileges":'  			||coalesce(l_privileges,'""')
			||', "user_config":'  			||coalesce(l_user_config,'""')
			||', "first_name":'  			||coalesce(to_json(l_first_name)::text,'""')
			||', "last_name":'   			||coalesce(to_json(l_last_name)::text,'""')
			||', "is_new_device_login":' 	||coalesce(to_json(l_is_new_device_login)::text,'"n"')
			||', "client_id":'     			||coalesce(to_json(l_client_id)::text,'""')
			||', "acct_state":'     		||coalesce(to_json(l_acct_state)::text,'""')
			||', "is_new_device_msg":' 		||coalesce(to_json(l_is_new_device_msg)::text,'"--not-set--')
			||'}';

	else
		if l_user_id is not null then
			insert into q_qr_auth_security_log ( user_id, activity, location ) values ( l_user_id, 'Login Failure', 'File:001.tables.m4.sql Line No:6125');
			if l_failed_login_timeout is not null then
				update q_qr_users
					set login_failures = login_failures + 1
					where user_id = l_user_id
					  and failed_login_timeout is not null
					  and login_failures >= 6
					;
			else
				update q_qr_users
					set login_failures = login_failures + 1
					  , failed_login_timeout = current_timestamp + interval '1 minute'
					where user_id = l_user_id
					  and failed_login_timeout is null
					  and login_failures >= 6
					;
				update q_qr_users
					set login_failures = login_failures + 1
					where user_id = l_user_id
					  and failed_login_timeout is null
					  and login_failures < 6
					;
			end if;
		end if;
	end if;

	RETURN l_data;
END;
$$ LANGUAGE plpgsql;

