
create table q_qr_user (
	user_id 				serial not null primary key,
	email_hmac 				text not null,
	password_enc 			text not null,
	real_name_hmac			text not null,
	email_verified			varchar(1) default 'n' not null,
	email_verify_token		uuid,
	password_reset_token	uuid,
	password_reset_time		timestamp,
	parent_user_id 			int,
	account_type			varchar(20) default 'login' not null check account_type in ( 'login', 'un/pw', 'token', 'other' )
	require_2fa 			varchar(1) default 'y' not null,
	secret_2fa 				varchar(20),
	start_date				timestamp default current_timestamp not null, 						
	end_date				timestamp,
	privilages				jsonb,
	updated 				timestamp, 									 						-- Project update timestamp (YYYYMMDDHHMMSS timestamp).
	created 				timestamp default current_timestamp not null 						-- Project creation timestamp (YYYYMMDDHHMMSS timestamp).
);

--
-- account_type
--		login		un/pw + 2fa token
--		un/pw		require_2fa = 'n'
--		token		just a email_hmac that is the "token"
--		other		??
--

create index q_qr_user_p1 on q_qr_user using hash ( email_hmac, email_verified );
create index q_qr_user_p2 on q_qr_user ( password_reset_token )
	where password_reset_token is not null;
create index q_qr_user_p3 on q_qr_user ( email_verify_token );
	where email_verify_token is not null;

create table q_qr_auth_token (
	auth_token_id 	serial not null primary key,
	user_id			int not null references q_qr_user ( user_id ),
	auth_token		uuid not null,
	expires			timestamp
);

create index q_qr_auth_token_p1 on q_qr_auth_token using hash ( auth_token );

--
-- List of 20 one-time passwrods for a user that they get on registration.
-- Can be "re-generated".
-- OTP is used to login as a password, then password is deleted.
-- OTP's are 16 digit numbers/text xxxx-xxxx-xxxx-xxxx (with a verhoff)
--
create table q_qr_2fa_otp (
	otp_id		 		serial not null primary key,
	user_id				int not null references q_qr_user ( user_id ),
	one_time_password	text,
	created 			timestamp default current_timestamp not null 						-- Project creation timestamp (YYYYMMDDHHMMSS timestamp).
);

create index q_qr_2fa_otp_p1 on q_qr_2fa_otp using hash ( user_id, one_time_password );

--	
-- A log of all the actions taken on this account that are security 
-- related.
--
-- 	action     				description
--	create					new account created
--	email-verified			email has been verified by users
--	passwrod-reset		
--	login
--	logout
--	login-fail-password
--	login-fail-2fa-otp
--	login-otp				login used a one-time-passwrod
--	
create table q_qr_auth_log (
	auth_log_id 	bigserial not null primary key,
	user_id			int not null references q_qr_user ( user_id ),
	action			text,
	created 		timestamp default current_timestamp not null 						-- Project creation timestamp (YYYYMMDDHHMMSS timestamp).
);

