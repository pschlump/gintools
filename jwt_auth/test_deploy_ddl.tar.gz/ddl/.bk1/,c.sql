		select
			  user_id
		    , pgp_sym_decrypt(real_name_enc,'user info password')
		from q_qr_users;
