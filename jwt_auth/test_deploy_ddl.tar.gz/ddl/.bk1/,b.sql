
create or replace function q_auth_v1_email_verify ( p_email_verify_token varchar )
	returns text
	as $$
DECLARE
	l_data					text;
	l_fail					bool;
	v_cnt 					int;
	l_verified				text;
BEGIN
	-- version: m4_ver_version() tag: m4_ver_tag() build_date: m4_ver_date()
	l_fail = false;
	l_data = '{"status":"unknown"}';

	update q_qr_users 
		set email_verified = 'y'
		  , email_verify_token = null
		  , email_verify_expire = null
	where email_verify_expire > current_timestamp
		and email_verify_token = p_email_verify_token::uuid
	;
	GET DIAGNOSTICS v_cnt = ROW_COUNT;
	if v_cnt != 1 then
		l_fail = true;
		l_data = '{"status":"failed","msg":"Unable to validate account via email.  Please register again."}'; -- return no such account or password
		delete from q_qr_users
			where email_verify_expire < current_timestamp
			  and email_verified = 'n'
			  and email_verify_token is not null
			;
	end if;

	if not l_fail then
		l_data = '{"status":"success"'
			||'}';
	end if;

	RETURN l_data;
END;
$$ LANGUAGE plpgsql;
