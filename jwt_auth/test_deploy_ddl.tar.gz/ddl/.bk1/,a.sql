select q_auth_v1_email_verify ( email_verify_token::text )
	from q_qr_users
;

select q_auth_v1_login ( 'bob@example.com', 'bob the builder', 'my long secret password', 'user info password' );
