
-- BSD 3 Clause Licensed.  See LICENSE.bsd

m4_include(setup.m4)

drop view if exists q_qr_valid_token ;
drop table if exists q_qr_track_file cascade;
drop table if exists q_qr_track_by_group cascade;
drop table if exists q_qr_track_by_id cascade;
drop table if exists q_qr_code cascade;
drop table if exists q_qr_auth_tokens cascade ;
drop table if exists q_qr_users cascade;
drop table if exists q_qr_headers cascade;

create table if not exists q_qr_code (
	qr_code_id 			serial not null primary key,
	qr_type				varchar(30) not null default 'redirect' check ( qr_type in ( 'unknown', 'redirect', 'proxy', 'direct' ) ),
	qrid10				varchar(10) not null,
	body				text not null,		-- what is encoded in the QR
	file_name			text not null,		-- local relative file name
	url_name			text not null,		-- URL path to file
	owner_user_id		int,
	group_id			int,
	redirect_to			text,
	full_text_search 	tsvector,			-- TODO - add trigger and populate from split of body.
	encoding 			varchar(30) not null default 'text',
	img_size 			int not null default 256,
	redundancy			varchar(1) default 'M' check ( redundancy in ( 'M', 'H', 'L' ) ) not null,
	invert				varchar(1) default 'r' check ( invert in ( 'r', 'i' ) ) not null,
	direct				varchar(15) default 'proxy' check ( direct in ( 'direct', 'proxy' ) ) not null,
	add_ran				text default '' not null,									 		-- if not "", then add this as a random value to destination
	updated 			timestamp, 									 						-- Project update timestamp (YYYYMMDDHHMMSS timestamp).
	created 			timestamp default current_timestamp not null 						-- Project creation timestamp (YYYYMMDDHHMMSS timestamp).
);

m4_updTrig(q_qr_code)

-- create index q_qr_code_h1 on q_qr_code using hash ( qrid10 );
create unique index q_qr_code_h1 on q_qr_code ( qrid10 );



create table if not exists q_qr_headers (
	header_id 			serial not null primary key,
	qr_code_id 			int not null references q_qr_code ( qr_code_id ),
	header_name			text not null,
	header_value		text not null,
	updated 			timestamp, 									 						-- Project update timestamp (YYYYMMDDHHMMSS timestamp).
	created 			timestamp default current_timestamp not null 						-- Project creation timestamp (YYYYMMDDHHMMSS timestamp).
);

m4_updTrig(q_qr_headers)



-- Tracking Tables --------------------------------------------------------------------------------------------------------------------------------


create table if not exists q_qr_track_by_id (
	qr_code_id 			int not null references q_qr_code ( qr_code_id ),
	created 			timestamp default current_timestamp not null 						-- Project creation timestamp (YYYYMMDDHHMMSS timestamp).
);

create index q_qr_track_by_id_p1 on q_qr_track_by_id ( created, qr_code_id );
create index q_qr_track_by_id_p2 on q_qr_track_by_id ( qr_code_id, created );


create table if not exists q_qr_track_by_group (
	qr_code_id 			int not null references q_qr_code ( qr_code_id ),
	group_id			int not null,
	created 			timestamp default current_timestamp not null 						-- Project creation timestamp (YYYYMMDDHHMMSS timestamp).
);

create index q_qr_track_by_group_p1 on q_qr_track_by_group ( created, group_id );
create index q_qr_track_by_group_p2 on q_qr_track_by_group ( group_id, created );

create table if not exists q_qr_track_file (
	qr_code_id 			int not null references q_qr_code ( qr_code_id ),
	file_name			text not null,		-- local relative file name
	created 			timestamp default current_timestamp not null 						-- Project creation timestamp (YYYYMMDDHHMMSS timestamp).
);

create index q_qr_track_file_p1 on q_qr_track_file ( created, qr_code_id );
create index q_qr_track_file_p2 on q_qr_track_file ( qr_code_id, created );

create index q_qr_track_file_p3 on q_qr_track_file ( file_name, created );
create index q_qr_track_file_p4 on q_qr_track_file ( created, file_name );


CREATE EXTENSION if not exists pgcrypto;

-- CREATE TABLE if not exists q_qr_users (
-- 	user_id 			serial primary key not null,
-- 	email_address 		text not null,
-- 	password 			text not null,
-- 	updated 			timestamp, 									 						-- Project update timestamp (YYYYMMDDHHMMSS timestamp).
-- 	created 			timestamp default current_timestamp not null 						-- Project creation timestamp (YYYYMMDDHHMMSS timestamp).
-- );
-- create table q_qr_user (
-- ?? add expire time for email_verify_token
-- ?? add links to drivers licnese images
-- ?? add per-user info - license number
CREATE TABLE if not exists q_qr_users (
	user_id 				serial not null primary key,
	email_hmac 				text not null,
	password_enc 			text not null,
	real_name_hmac			text not null,
	email_verified			varchar(1) default 'n' not null,
	email_verify_token		uuid,
	password_reset_token	uuid,
	password_reset_time		timestamp,
	parent_user_id 			int,
	account_type			varchar(20) default 'login' not null check ( account_type in ( 'login', 'un/pw', 'token', 'other' ) ),
	require_2fa 			varchar(1) default 'y' not null,
	secret_2fa 				varchar(20),
	start_date				timestamp default current_timestamp not null,
	end_date				timestamp,
	privilages				jsonb,
	updated 				timestamp, 									 						-- Project update timestamp (YYYYMMDDHHMMSS timestamp).
	created 				timestamp default current_timestamp not null 						-- Project creation timestamp (YYYYMMDDHHMMSS timestamp).
);

CREATE UNIQUE INDEX q_qr_users_u1 on q_qr_users ( email_hmac );

CREATE INDEX q_qr_users_enc_p1 on q_qr_users using HASH (  email_hmac );

m4_updTrig(q_qr_users)

INSERT INTO q_qr_users (email_hmac, password_enc, real_name_hmac) VALUES
	  ( encode(hmac('testAcct1@email.com', 'my-long-secret', 'sha256'), 'hex'), crypt('Think Pink Ink 9434', gen_salt('bf') ), 'test user 1' )
	, ( encode(hmac('testAcct2@email.com', 'my-long-secret', 'sha256'), 'hex'), crypt('Mimsey!81021', gen_salt('bf') ), 'test user 2' )
;

-- SELECT encode(digest('testAcct1@email.com', 'sha1'), 'hex');
-- https://stackoverflow.com/questions/52865791/postgresql10-pgcrypto-hmac-how-to-recalculate-data
-- CREATE INDEX fxix_user_id ON APP.USER(ENCODE(HMAC( USER_ID::TEXT, 'MY_KEY', 'SHA256'), 'HEX));

CREATE TABLE if not exists q_qr_auth_tokens (
  auth_token_id 	serial primary key not null,
  user_id 			int not null,
  token			 	uuid not null,
  expires 			timestamp not null
);

create unique index q_qr_auth_tokens_u1 on q_qr_auth_tokens ( token );
create index q_qr_auth_tokens_p1 on q_qr_auth_tokens ( user_id );
create index q_qr_auth_tokens_p2 on q_qr_auth_tokens ( expires );

ALTER TABLE q_qr_auth_tokens
	ADD CONSTRAINT q_qr_auth_tokens_fk1
	FOREIGN KEY (user_id)
	REFERENCES q_qr_users (user_id)
;


CREATE OR REPLACE function q_qr_auth_token_expires()
RETURNS trigger AS $$
BEGIN
	NEW.expires := current_timestamp + interval '31 days';
	RETURN NEW;
END
$$ LANGUAGE 'plpgsql';


CREATE TRIGGER q_qr_users_expire_trig
	BEFORE insert or update ON "q_qr_auth_tokens"
	FOR EACH ROW
	EXECUTE PROCEDURE q_qr_auth_token_expires();

CREATE OR REPLACE view q_qr_valid_token as
	select
		auth_token_id,
		user_id,
		token
	from q_qr_auth_tokens
	where expires < current_timestamp
	;





-- stmt := "select q_auth_v1_login ( $1, $2, $3 ) as \"X\""

create or replace function q_auth_v1_login ( p_un varchar, p_pw varchar, p_password varchar )
	returns text
	as $$
DECLARE
	l_2fa_id				uuid;
	l_data					text;
	l_fail					bool;
  	l_user_id 				int;
	l_email_verified		varchar(1);
	l_start_date			timestamp;
	l_end_date				timestamp;
	l_require_2fa 			varchar(1);
	l_secret_2fa 			varchar(20);
	l_account_type			varchar(20);
	l_privilages			jsonb;
	l_real_name_hmac		text;
	l_auth_token			uuid;

	-- l_email_verify_token		uuid;
	-- l_password_reset_token	uuid;
	-- l_password_reset_time	timestamp;
	-- l_parent_user_id 		int;
BEGIN
	-- version: m4_ver_version() tag: m4_ver_tag() build_date: m4_ver_date()
	l_fail = false;
	l_data = '{"status":"unknown"}';

	if not l_fail then
		select
			  user_id
			, email_verified
			, start_date
			, end_date
			, require_2fa
			, secret_2fa
			, account_type
			, privilages
			, real_name_hmac
		into
			  l_user_id
			, l_email_verified
			, l_start_date
			, l_end_date
			, l_require_2fa
			, l_secret_2fa
			, l_account_type
			, l_privilages
			, l_real_name_hmac
		from q_qr_users
		where ( email_hmac = encode(hmac(p_un, p_password, 'sha256'), 'hex')
		    and password_enc = crypt(p_pw, password_enc)
			and account_type in ( 'login', 'un/pw' ) )
		or     ( email_hmac = encode(hmac(p_un, p_password, 'sha256'), 'hex')
			and account_type = 'token' )
		;
		if not found then
			l_fail = true;
			l_data = '{"status":"failed","msg":"Invalid Username or Password"}'; -- return no such account or password
		end if;
	end if;

	if not l_fail then
		if l_email_verified = 'n' then
			l_fail = true;
			l_data = '{"status":"failed","msg":"Account has not not been verified"}';
		end if;
	end if;
	if not l_fail then
		if l_start_date is not null then
			if l_start_date < current_time then
				l_fail = true;
				l_data = '{"status":"failed","msg":"Account has a start date that has not been reached"}';
			end if;
		end if;
	end if;
	if not l_fail then
		if l_end_date is not null then
			if l_end_date > current_time then
				l_fail = true;
				l_data = '{"status":"failed","msg":"Account has a end date that has not been reached"}';
			end if;
		end if;
	end if;

	if not l_fail then
		if l_require_2fa = 'n' then
			-- insert / create auth_token
			l_auth_token = uuid_generate_v4();
			BEGIN
				insert into q_qr_auth_tokens ( token, user_id ) values ( l_auth_token, l_user_id );
			EXCEPTION WHEN unique_violation THEN
				l_fail = true;
				l_data = '{"status":"error","msg":"Unable to create user/auth-token."}';
			END;
		end if;
	end if;

	if not l_fail then
		l_data = '{"status":"success"'
			||', "user_id":'     ||coalesce(to_json(p_id)::text,'""')
			||', "auth_token":'  ||coalesce(to_json(l_auth_token)::text,'""')
			||', "require_2fa":' ||coalesce(to_json(l_require_2fa)::text,'""')
			||', "secret_2fa":'  ||coalesce(to_json(l_secret_2fa)::text,'""')
			||', "account_type":'||coalesce(to_json(l_account_type)::text,'""')
			||', "privileages":' ||coalesce(to_json(l_privilages)::text,'""')
			||'}';
	-- l_real_name_hmac		text;
	end if;

	RETURN l_data;
END;
$$ LANGUAGE plpgsql;



create or replace function q_auth_v1_register ( p_un varchar, p_pw varchar, p_password varchar, p_real_name varchar )
	returns text
	as $$
DECLARE
	l_data					text;
	l_fail					bool;
	l_user_id				int;
	l_email_verify_token	uuid;
	l_tmp 					varchar(40);
	l_secret_2fa 			varchar(20);
BEGIN
	-- version: m4_ver_version() tag: m4_ver_tag() build_date: m4_ver_date()
	l_fail = false;
	l_data = '{"status":"unknown"}';

	l_email_verify_token = uuid_generate_v4();

	l_tmp = uuid_generate_v4()::text;
	l_secret_2fa = substr(l_tmp,0,8) || substr(l_tmp,9,14);

	INSERT INTO q_qr_users (
			  email_hmac
			, password_enc
			, email_verify_token
			, secret_2fa
		) VALUES (
			  encode(hmac(p_un, p_password, 'sha256'), 'hex')
			, crypt(p_pw, gen_salt('bf') )
			, l_email_verify_token
			, l_secret_2fa
		) returning user_id into l_user_id  ;

	if not l_fail then
		l_data = '{"status":"success"'
			||', "user_id":' ||coalesce(to_json(l_user_id)::text,'""')
			||', "email_verify_token":' ||coalesce(to_json(l_email_verify_token)::text,'""')
			||', "secret_2fa":' ||coalesce(to_json(l_secret_2fa)::text,'""')
			||'}';
	end if;

	RETURN l_data;
END;
$$ LANGUAGE plpgsql;



select q_auth_v1_register ( 'bob@example.com', 'bob the builder', 'my long secret password', 'Bob the Builder' );

