
-- Copyright (C) Philip Schlump, 2008-2021.
-- BSD 3 Clause Licensed.  See LICENSE.bsd

drop table if exists t_output ;
create table if not exists t_output (
	seq serial not null primary key,
	msg text
);

-- ** xyzzy - TODO - validate 2fa token
-- xyzzy - TODO - login via OTP - otp list
-- xyzzy - TODO - otp list
-- xyzzy - TODO - new otp list

-- + xyzzy - TODO - account activity log -- table created.
-- xyzzy - TODO - change password -- start passwrod reset -- creates tokens
-- xyzzy - TODO - change password -- reset passwrod  - allows reset
-- xyzzy - TODO - change password 
-- xyzzy - TODO - change password admin priv -

-- xyzzy - TODO - privilages tables
-- xyzzy - TODO - privilages tables - create role / update role etc.

-- xyzzy - TODO - register un/pw account - child account
-- xyzzy - TODO - register token account - child account

-- ?? add links to drivers licnese images
-- ?? add per-user info - license number

drop view if exists q_qr_valid_token ;
drop table if exists q_qr_track_file cascade;
drop table if exists q_qr_track_by_group cascade;
drop table if exists q_qr_track_by_id cascade;
drop table if exists q_qr_code cascade;
drop table if exists q_qr_auth_tokens cascade ;
drop table if exists q_qr_users cascade;
drop table if exists q_qr_headers cascade;
drop table if exists q_qr_auth_security_log cascade;

create table if not exists q_qr_code (
	qr_code_id 			serial not null primary key,
	qr_type				varchar(30) not null default 'redirect' check ( qr_type in ( 'unknown', 'redirect', 'proxy', 'direct' ) ),
	qrid10				varchar(10) not null,
	body				text not null,		-- what is encoded in the QR
	file_name			text not null,		-- local relative file name
	url_name			text not null,		-- URL path to file
	owner_user_id		int,
	group_id			int,
	redirect_to			text,
	full_text_search 	tsvector,			-- TODO - add trigger and populate from split of body.
	encoding 			varchar(30) not null default 'text',
	img_size 			int not null default 256,
	redundancy			varchar(1) default 'M' check ( redundancy in ( 'M', 'H', 'L' ) ) not null,
	invert				varchar(1) default 'r' check ( invert in ( 'r', 'i' ) ) not null,
	direct				varchar(15) default 'proxy' check ( direct in ( 'direct', 'proxy' ) ) not null,
	add_ran				text default '' not null,									 		-- if not "", then add this as a random value to destination
	updated 			timestamp, 									 						-- Project update timestamp (YYYYMMDDHHMMSS timestamp).
	created 			timestamp default current_timestamp not null 						-- Project creation timestamp (YYYYMMDDHHMMSS timestamp).
);



CREATE OR REPLACE function q_qr_code_upd()
RETURNS trigger AS $$
BEGIN
	-- version: m4_ver_version() tag: m4_ver_tag() build_date: m4_ver_date()
	NEW.updated := current_timestamp;
	RETURN NEW;
END
$$ LANGUAGE 'plpgsql';


CREATE TRIGGER q_qr_code_trig
BEFORE update ON "q_qr_code"
FOR EACH ROW
EXECUTE PROCEDURE q_qr_code_upd();



-- create index q_qr_code_h1 on q_qr_code using hash ( qrid10 );
create unique index q_qr_code_h1 on q_qr_code ( qrid10 );



create table if not exists q_qr_headers (
	header_id 			serial not null primary key,
	qr_code_id 			int not null references q_qr_code ( qr_code_id ),
	header_name			text not null,
	header_value		text not null,
	updated 			timestamp, 									 						-- Project update timestamp (YYYYMMDDHHMMSS timestamp).
	created 			timestamp default current_timestamp not null 						-- Project creation timestamp (YYYYMMDDHHMMSS timestamp).
);



CREATE OR REPLACE function q_qr_headers_upd()
RETURNS trigger AS $$
BEGIN
	-- version: m4_ver_version() tag: m4_ver_tag() build_date: m4_ver_date()
	NEW.updated := current_timestamp;
	RETURN NEW;
END
$$ LANGUAGE 'plpgsql';


CREATE TRIGGER q_qr_headers_trig
BEFORE update ON "q_qr_headers"
FOR EACH ROW
EXECUTE PROCEDURE q_qr_headers_upd();





-- Tracking Tables --------------------------------------------------------------------------------------------------------------------------------


create table if not exists q_qr_track_by_id (
	qr_code_id 			int not null references q_qr_code ( qr_code_id ),
	created 			timestamp default current_timestamp not null 						-- Project creation timestamp (YYYYMMDDHHMMSS timestamp).
);

create index q_qr_track_by_id_p1 on q_qr_track_by_id ( created, qr_code_id );
create index q_qr_track_by_id_p2 on q_qr_track_by_id ( qr_code_id, created );


create table if not exists q_qr_track_by_group (
	qr_code_id 			int not null references q_qr_code ( qr_code_id ),
	group_id			int not null,
	created 			timestamp default current_timestamp not null 						-- Project creation timestamp (YYYYMMDDHHMMSS timestamp).
);

create index q_qr_track_by_group_p1 on q_qr_track_by_group ( created, group_id );
create index q_qr_track_by_group_p2 on q_qr_track_by_group ( group_id, created );

create table if not exists q_qr_track_file (
	qr_code_id 			int not null references q_qr_code ( qr_code_id ),
	file_name			text not null,		-- local relative file name
	created 			timestamp default current_timestamp not null 						-- Project creation timestamp (YYYYMMDDHHMMSS timestamp).
);

create index q_qr_track_file_p1 on q_qr_track_file ( created, qr_code_id );
create index q_qr_track_file_p2 on q_qr_track_file ( qr_code_id, created );

create index q_qr_track_file_p3 on q_qr_track_file ( file_name, created );
create index q_qr_track_file_p4 on q_qr_track_file ( created, file_name );


CREATE EXTENSION if not exists pgcrypto;

-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

CREATE TABLE if not exists q_qr_users (
	user_id 				serial not null primary key,
	email_hmac 				text not null,
	password_hash 			text not null,
	real_name_enc			bytea not null,
	email_verified			varchar(1) default 'n' not null,
	email_verify_token		uuid,
	email_verify_expire 	timestamp,
	password_reset_token	uuid,
	password_reset_time		timestamp,
	failed_login_timeout 	timestamp,
	login_failures 			int default 0 not null,
	parent_user_id 			int,
	account_type			varchar(20) default 'login' not null check ( account_type in ( 'login', 'un/pw', 'token', 'other' ) ),
	require_2fa 			varchar(1) default 'y' not null,
	secret_2fa 				varchar(20),
	start_date				timestamp default current_timestamp not null,
	end_date				timestamp,
	privilages				jsonb,
	updated 				timestamp, 									 						-- Project update timestamp (YYYYMMDDHHMMSS timestamp).
	created 				timestamp default current_timestamp not null 						-- Project creation timestamp (YYYYMMDDHHMMSS timestamp).
);

CREATE UNIQUE INDEX q_qr_users_u1 on q_qr_users ( email_hmac );

CREATE INDEX q_qr_users_enc_p1 on q_qr_users using HASH ( email_hmac );

CREATE INDEX q_qr_users_enc_p2 on q_qr_users ( email_verify_expire, email_verified )
	where email_verify_expire is not null;
CREATE INDEX q_qr_users_enc_p3 on q_qr_users ( email_verify_token, email_verified )
	where email_verify_token is not null;

CREATE INDEX q_qr_users_enc_p4 on q_qr_users ( password_reset_token )
	where password_reset_token is not null;

CREATE OR REPLACE function q_qr_users_upd()
RETURNS trigger AS $$
BEGIN
	-- version: m4_ver_version() tag: m4_ver_tag() build_date: m4_ver_date()
	NEW.updated := current_timestamp;
	RETURN NEW;
END
$$ LANGUAGE 'plpgsql';


CREATE TRIGGER q_qr_users_trig
BEFORE update ON "q_qr_users"
FOR EACH ROW
EXECUTE PROCEDURE q_qr_users_upd();



INSERT INTO q_qr_users (email_hmac, password_hash, real_name_enc) VALUES
	  ( encode(hmac('testAcct1@email.com', 'my-long-secret', 'sha256'), 'hex'), crypt('Think Pink Ink 9434', gen_salt('bf') )
		    , pgp_sym_encrypt('Test User 1','p_userdata_password') )
	, ( encode(hmac('testAcct2@email.com', 'my-long-secret', 'sha256'), 'hex'), crypt('Mimsey!81021', gen_salt('bf') )
		    , pgp_sym_encrypt('Test User 1','p_userdata_password') )
;

		    -- , encode(pgp_sym_encrypt(p_real_name,p_userdata_password),'base64')
					  -- encode(pgp_sym_encrypt(p_username,p_key),'base64')
-- SELECT encode(digest('testAcct1@email.com', 'sha1'), 'hex');
-- https://stackoverflow.com/questions/52865791/postgresql10-pgcrypto-hmac-how-to-recalculate-data
-- CREATE INDEX fxix_user_id ON APP.USER(ENCODE(HMAC( USER_ID::TEXT, 'MY_KEY', 'SHA256'), 'HEX));

-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

CREATE TABLE if not exists q_qr_auth_tokens (
  auth_token_id 	serial primary key not null,
  user_id 			int not null,
  token			 	uuid not null,
  expires 			timestamp not null
);

create unique index q_qr_auth_tokens_u1 on q_qr_auth_tokens ( token );
create index q_qr_auth_tokens_p1 on q_qr_auth_tokens ( user_id );
create index q_qr_auth_tokens_p2 on q_qr_auth_tokens ( expires );

ALTER TABLE q_qr_auth_tokens
	ADD CONSTRAINT q_qr_auth_tokens_fk1
	FOREIGN KEY (user_id)
	REFERENCES q_qr_users (user_id)
;


CREATE OR REPLACE function q_qr_auth_token_expires()
RETURNS trigger AS $$
BEGIN
	NEW.expires := current_timestamp + interval '31 days';
	RETURN NEW;
END
$$ LANGUAGE 'plpgsql';


CREATE TRIGGER q_qr_users_expire_trig
	BEFORE insert or update ON "q_qr_auth_tokens"
	FOR EACH ROW
	EXECUTE PROCEDURE q_qr_auth_token_expires();

CREATE OR REPLACE view q_qr_valid_token as
	select
		auth_token_id,
		user_id,
		token
	from q_qr_auth_tokens
	where expires < current_timestamp
;





-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

CREATE TABLE if not exists q_qr_auth_security_log (
	security_log_id 	serial primary key not null,
	user_id 			int not null,
	activity			text,
	created 			timestamp default current_timestamp not null 						-- Project creation timestamp (YYYYMMDDHHMMSS timestamp).
);




-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

-- Called with:
-- stmt := "select q_auth_v1_login ( $1, $2, $3, $4 ) as \"X\""

create or replace function q_auth_v1_login ( p_un varchar, p_pw varchar, p_hmac_password varchar, p_userdata_password varchar )
	returns text
	as $$
DECLARE
	l_2fa_id				uuid;
	l_data					text;
	l_fail					bool;
  	l_user_id 				int;
	l_email_verified		varchar(1);
	l_start_date			timestamp;
	l_end_date				timestamp;
	l_require_2fa 			varchar(1);
	l_secret_2fa 			varchar(20);
	l_account_type			varchar(20);
	l_privilages			jsonb;
	l_real_name				text;
	l_tmp					text;
	l_auth_token			uuid;
	l_debug_on 				bool;
	l_failed_login_timeout 	timestamp;
	l_login_failures 		int;

	-- l_email_verify_token		uuid;
	-- l_password_reset_token	uuid;
	-- l_password_reset_time	timestamp;
	-- l_parent_user_id 		int;
BEGIN
	l_debug_on = false;

	-- Copyright (C) Philip Schlump, 2008-2021.
	-- version: m4_ver_version() tag: m4_ver_tag() build_date: m4_ver_date()
	l_fail = false;
	l_data = '{"status":"unknown"}';

	-- Cleanup old auth tokens.
	delete from q_qr_auth_tokens 
		where expires < current_timestamp
		;

	if not l_fail then
		select
			  user_id
			, email_verified
			, start_date
			, end_date
			, require_2fa
			, secret_2fa
			, account_type
			, privilages
		    , pgp_sym_decrypt(real_name_enc,p_userdata_password)::text
			, failed_login_timeout 	
			, login_failures 		
		into
			  l_user_id
			, l_email_verified
			, l_start_date
			, l_end_date
			, l_require_2fa
			, l_secret_2fa
			, l_account_type
			, l_privilages
			, l_real_name
			, l_failed_login_timeout 	
			, l_login_failures 	
		from q_qr_users
		where ( email_hmac = encode(hmac(p_un, p_hmac_password, 'sha256'), 'base64')
		    and password_hash = crypt(p_pw, password_hash)
			and account_type in ( 'login', 'un/pw' ) )
		or     ( email_hmac = encode(hmac(p_un, p_hmac_password, 'sha256'), 'base64')
			and account_type = 'token' )
		;
		if not found then
			l_fail = true;
			l_data = '{"status":"error","msg":"Invalid Username or Password"}'; -- return no such account or password
		end if;
	end if;

	if l_debug_on then
		insert into t_output ( msg ) values ( '->'||p_userdata_password||'<-');
		insert into t_output ( msg ) values ( 'l_real_name = ->'||l_real_name||'<-');
		--select pgp_sym_decrypt(l_real_name::bytea,p_userdata_password)::text
		--	into l_tmp;
		--insert into t_output ( msg ) values ( 'l_tmp = ->'||l_tmp||'<-');
	end if;

	if not l_fail then
		if l_email_verified = 'n' then
			l_fail = true;
			l_data = '{"status":"error","msg":"Account has not not been verified"}';
		end if;
	end if;
	if not l_fail then
		if l_start_date is not null then
			if l_start_date > current_timestamp then
				l_fail = true;
				l_data = '{"status":"error","msg":"Account has a start date that has not been reached"}';
			end if;
		end if;
	end if;
	if not l_fail then
		if l_end_date is not null then
			if l_end_date <= current_timestamp then
				l_fail = true;
				l_data = '{"status":"error","msg":"Account has a end date that has been reached"}';
			end if;
		end if;
	end if;

	if not l_fail then
		if l_require_2fa = 'n' then
			-- insert / create auth_token
			l_auth_token = uuid_generate_v4();
			BEGIN
				insert into q_qr_auth_tokens ( token, user_id ) values ( l_auth_token, l_user_id );
			EXCEPTION WHEN unique_violation THEN
				l_fail = true;
				l_data = '{"status":"error","msg":"Unable to create user/auth-token."}';
			END;
		end if;
	end if;
	if not l_fail then
		if l_login_failures > 6 or l_failed_login_timeout >= current_timestamp then
			l_fail = true;
			l_data = '{"status":"error","msg":"too many failed attempts to login - please wait 1 minute"}';
			update q_qr_users
				set failed_login_timeout = current_timestamp + interval '1 minute'
				where user_id = l_user_id
				  and failed_login_timeout is null
				;
		end if;
	end if;

	if not l_fail then
		insert into q_qr_auth_security_log ( user_id, activity ) values ( l_user_id, 'Successful Login');
		update q_qr_users
			set 
				  failed_login_timeout = null
				, login_failures = 0
			where user_id = l_user_id
			;
		l_data = '{"status":"success"'
			||', "user_id":'     ||coalesce(to_json(l_user_id)::text,'""')
			||', "auth_token":'  ||coalesce(to_json(l_auth_token)::text,'""')
			||', "require_2fa":' ||coalesce(to_json(l_require_2fa)::text,'""')
			||', "secret_2fa":'  ||coalesce(to_json(l_secret_2fa)::text,'""')
			||', "account_type":'||coalesce(to_json(l_account_type)::text,'""')
			||', "privileages":' ||coalesce(to_json(l_privilages)::text,'"{}"')
			||', "real_name":'   ||coalesce(to_json(l_real_name)::text,'""')
			||'}';
	else 
		if l_user_id is not null then
			insert into q_qr_auth_security_log ( user_id, activity ) values ( l_user_id, 'Login Failure');
			update q_qr_users
				set login_failures = login_failures + 1 
				where user_id = l_user_id
				;
		end if;
	end if;

	RETURN l_data;
END;
$$ LANGUAGE plpgsql;


-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

create or replace function q_auth_v1_register ( p_un varchar, p_pw varchar, p_hmac_password varchar, p_real_name varchar, p_userdata_password varchar )
	returns text
	as $$
DECLARE
	l_data					text;
	l_fail					bool;
	l_user_id				int;
	l_bad_user_id			int;
	l_email_verify_token	uuid;
	l_tmp 					varchar(40);
	l_secret_2fa 			varchar(20);
	l_debug_on 				bool;
BEGIN
	l_debug_on = false;

	-- Copyright (C) Philip Schlump, 2008-2021.
	-- version: m4_ver_version() tag: m4_ver_tag() build_date: m4_ver_date()
	l_fail = false;
	l_data = '{"status":"unknown"}';

	l_email_verify_token = uuid_generate_v4();

	l_tmp = uuid_generate_v4()::text;
	l_secret_2fa = substr(l_tmp,0,7) || substr(l_tmp,10,4);

	if l_debug_on then
		insert into t_output ( msg ) values ( '->'||p_userdata_password||'<-');
	end if;

	-- Cleanup any users that have expired tokens.
	delete from q_qr_users
		where email_verify_expire < current_timestamp
		  and email_verify_token is not null
		  and email_verified = 'n'
		;

	select user_id
		into l_bad_user_id
		from q_qr_users
		where email_hmac = encode(hmac(p_un, p_hmac_password, 'sha256'), 'base64')
		;
	if found then
		l_fail = true;
		l_data = '{"status":"error","msg":"Account already exists.  Please login or recover password."}';
		insert into q_qr_auth_security_log ( user_id, activity ) values ( l_bad_user_id, 'User Attempt to Re-Register Same Accont');
	end if;

	if not l_fail then
		insert into q_qr_auth_security_log ( user_id, activity ) values ( l_user_id, 'User Registered');
		INSERT INTO q_qr_users (
			  email_hmac
			, password_hash
			, email_verify_token
			, email_verify_expire
			, secret_2fa
			, real_name_enc
		) VALUES (
			  encode(hmac(p_un, p_hmac_password, 'sha256'), 'base64')
			, crypt(p_pw, gen_salt('bf') )
			, l_email_verify_token
			, current_timestamp + interval '1 day'
			, l_secret_2fa
		    , pgp_sym_encrypt(p_real_name,p_userdata_password)
		) returning user_id into l_user_id  ;
	end if;

	if not l_fail then
		l_data = '{"status":"success"'
			||', "user_id":' ||coalesce(to_json(l_user_id)::text,'""')
			||', "email_verify_token":' ||coalesce(to_json(l_email_verify_token)::text,'""')
			||', "secret_2fa":' ||coalesce(to_json(l_secret_2fa)::text,'""')
			||'}';
	end if;

	RETURN l_data;
END;
$$ LANGUAGE plpgsql;

-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

create or replace function q_auth_v1_email_verify ( p_email_verify_token varchar )
	returns text
	as $$
DECLARE
	l_data					text;
	l_fail					bool;
	v_cnt 					int;
	l_verified				text;
BEGIN
	-- Copyright (C) Philip Schlump, 2008-2021.
	-- version: m4_ver_version() tag: m4_ver_tag() build_date: m4_ver_date()
	l_fail = false;
	l_data = '{"status":"unknown"}';

	update q_qr_users 
		set email_verified = 'y'
		  , email_verify_token = null
		  , email_verify_expire = null
	where email_verify_expire > current_timestamp
		and email_verify_token = p_email_verify_token::uuid
	;
	GET DIAGNOSTICS v_cnt = ROW_COUNT;
	if v_cnt != 1 then
		l_fail = true;
		l_data = '{"status":"error","msg":"Unable to validate account via email.  Please register again."}'; 
		-- Cleanup any users that have expired tokens.
		delete from q_qr_users
			where email_verify_expire < current_timestamp
			  and email_verified = 'n'
			  and email_verify_token is not null
			;
	end if;

	if not l_fail then
		l_data = '{"status":"success"'
			||'}';
	end if;

	RETURN l_data;
END;
$$ LANGUAGE plpgsql;



-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

create or replace function q_auth_v1_logout ( p_un varchar, p_auth_token varchar, p_hmac_password varchar )
	returns text
	as $$
DECLARE
	l_data					text;
	l_fail					bool;
BEGIN
	-- version: m4_ver_version() tag: m4_ver_tag() build_date: m4_ver_date()
	l_fail = false;
	l_data = '{"status":"unknown"}';

	delete from q_qr_auth_tokens as t1
		where t1.token = p_auth_token
		  and exists (
			select 'found'
			from q_qr_users as t2
			where t2.email_hmac = encode(hmac(p_un, p_hmac_password, 'sha256'), 'base64')
			  and t2.user_id = t1.user_id
		  )
		;

	if not l_fail then
		l_data = '{"status":"success"'
			||'}';
	end if;

	RETURN l_data;
END;
$$ LANGUAGE plpgsql;



-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

create or replace function q_auth_v1_validate_2fa_token ( p_un varchar, p_2fa_secret varchar, p_hmac_password varchar )
	returns text
	as $$
DECLARE
	l_data					text;
	l_fail					bool;
	l_user_id				int;
	l_auth_token 			uuid;
	l_privilages			jsonb;
BEGIN
	-- Copyright (C) Philip Schlump, 2008-2021.
	-- version: m4_ver_version() tag: m4_ver_tag() build_date: m4_ver_date()
	l_fail = false;
	l_data = '{"status":"unknown"}';

	select user_id
			, privilages
		into l_user_id
			, l_privilages
		from q_qr_users as t2
		where t2.email_hmac = encode(hmac(p_un, p_hmac_password, 'sha256'), 'base64')
		  and t2.secret_2fa = p_2fa_secret
		;
	if not found then
		l_fail = true;
		l_data = '{"status":"error","msg":"Invalid 2fa number"}';
	end if;

	if not l_fail then
		-- insert / create auth_token
		l_auth_token = uuid_generate_v4();
		BEGIN
			insert into q_qr_auth_tokens ( token, user_id ) values ( l_auth_token, l_user_id );
		EXCEPTION WHEN unique_violation THEN
			l_fail = true;
			l_data = '{"status":"error","msg":"Unable to create user/auth-token."}';
		END;
	end if;

	if not l_fail then
		l_data = '{"status":"success"'
			||', "auth_token":'  ||coalesce(to_json(l_auth_token)::text,'""')
			||', "user_id":'     ||coalesce(to_json(l_user_id)::text,'""')
			||', "privileages":' ||coalesce(to_json(l_privilages)::text,'"{}"')
			||'}';
	end if;

	RETURN l_data;
END;
$$ LANGUAGE plpgsql;


-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Tests
-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

delete from q_qr_users cascade;
delete from t_output;

select q_auth_v1_register ( 'bob@example.com', 'bob the builder', 'my long secret password', 'Bob the Builder', 'user info password' );

select * from t_output;

select * from q_qr_users;

select q_auth_v1_login ( 'bob@example.com', 'bob the builder', 'my long secret password', 'user info password' ); 
--  {"status":"error","msg":"Account has not not been verified"}

select * from t_output;

select q_auth_v1_email_verify ( email_verify_token::text )
	from q_qr_users
;

select * from t_output;

select q_auth_v1_login ( 'bob@example.com', 'bob the builder', 'my long secret password', 'user info password' );
--                               q_auth_v1_login
-- -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--  {"status":"success", "user_id":3, "auth_token":"", "require_2fa":"y", "secret_2fa":"3a120fcb9d", "account_type":"login", "privileages":"{}", "real_name":"\\xc30d040703020574bda261893b9468d24001e767894cb28cdf3239bfcb00b208943a6f27d625850ae86cdabfe92de75f51ad14e3a090341a19fbf2ac57ef630ed795d756c99c4580d315334e99d1b659b3"}

select * from t_output;
